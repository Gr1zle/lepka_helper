"""Подготовить новый серверный пакет по явному списку, без GUI, баз и секретов."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.coursework_files import FILES as COURSEWORK_FILES
MODULES=('interface_catalog','learning_catalog','notification_mail','delivery_settings','project_planner','lesson_library','offline_mutations','personal_vault','personal_snapshot','project_archive','project_service','model_import','mesh_renderer','account_security','activity_service','app_paths','auth_service','challenge_service','color_service',
 'contest_entry','database','feed_service','learning_assets','lesson_service','mail_service','moderation_service',
 'password_service','photo_service','post_service','profile_service','project_sharing','role_service','social_feed','validators','workshop_service')
ANDROID_FINAL_EVIDENCE = ('docs/android_final_evidence/apk.json', 'docs/android_final_evidence/apk_badging.txt', 'docs/android_final_evidence/apk_signature.txt', 'docs/android_final_evidence/browser.js.txt', 'docs/android_final_evidence/browser.json', 'docs/android_final_evidence/browser.log', 'docs/android_final_evidence/console.json', 'docs/android_final_evidence/screenshots/android-final-photo-applied.png', 'docs/android_final_evidence/screenshots/android-final-photo-full-0.png', 'docs/android_final_evidence/screenshots/android-final-photo-full-2.png', 'docs/android_final_evidence/screenshots/android-final-photo-return.png', 'docs/android_final_evidence/tests.json')
FILES=('CONSOLE_COMMANDS.md','docs/android_final.md', *ANDROID_FINAL_EVIDENCE,*COURSEWORK_FILES,'assets/i18n_en.json',*[m+'.py' for m in MODULES],'backend/__init__.py','backend/main.py','backend/community.py','backend/moderation.py',
 'backend/challenges.py','backend/personal.py','backend/delivery.py','backend/catalog.py','backend/requirements.txt','backend/Dockerfile','backend/README.md','backend/compose.yml',
 'backend/Caddyfile','backend/.env.example','docs/roles_admin_server.md','scripts/__init__.py','scripts/manage_admin.py','scripts/server_backup.py','scripts/run_wifi_server.py','scripts/create_server_demo.py','docs/wifi_server.md','docs/personal_vault_sync.md','docs/remaining_work.md','docs/notification_delivery.md','docs/learning_catalog.md','docs/color_camera_references.md','docs/design_system.md','docs/discovery_navigation.md','docs/project_workflow.md','docs/english_community.md','docs/interaction_fixes.md','docs/screenshots/interaction-fixes-compose-full.png','docs/screenshots/interaction-fixes-compose-photo.png','docs/screenshots/interaction-fixes-post-loaded.png','docs/screenshots/interaction-fixes-language-profile.png','docs/screenshots/interaction-fixes-language-russian.png','docs/screenshots/english-community-home-320.png','docs/screenshots/english-community-home-390.png','docs/screenshots/english-community-colors-390.png','docs/screenshots/english-community-colors-dark-820.png','docs/screenshots/english-community-create-post.png','docs/screenshots/english-community-alice-reply.png','docs/screenshots/english-community-alice-inbox.png','docs/screenshots/english-community-bob-inbox.png','docs/screenshots/project-workflow-detail-390.png','docs/screenshots/project-workflow-order-before.png','docs/screenshots/project-workflow-order-after.png','docs/screenshots/project-workflow-added-step.png','docs/screenshots/project-workflow-final-required.png','docs/screenshots/project-workflow-completed-320.png','docs/screenshots/project-workflow-publication.png','docs/screenshots/project-workflow-delete-confirm.png','docs/screenshots/project-workflow-dark-820.png','docs/screenshots/discovery-home-320.png','docs/screenshots/discovery-home-1440.png','docs/screenshots/discovery-search-empty.png','docs/screenshots/discovery-search-results.png','docs/screenshots/discovery-catalogue.png','docs/screenshots/discovery-post.png','docs/screenshots/discovery-create-project.png','docs/screenshots/discovery-project-list.png','docs/screenshots/discovery-project-detail.png','docs/screenshots/discovery-notifications.png','docs/screenshots/discovery-create-post.png','docs/screenshots/discovery-color-full.png','docs/screenshots/discovery-color-zoom.png','docs/screenshots/discovery-color-return.png','docs/screenshots/design-auth-390.png','docs/screenshots/design-home-390.png','docs/screenshots/design-colors-390.png','docs/screenshots/design-search-1440.png','docs/screenshots/design-projects-320.png','docs/screenshots/design-profile-390.png','docs/screenshots/design-colors-dark-320.png','docs/screenshots/design-colors-dark-1440.png','docs/screenshots/design-model-full-820.png','docs/screenshots/color-camera-dialog-320.png','docs/screenshots/color-reference-320.png','docs/screenshots/catalog-list-390.png','docs/screenshots/catalog-offline-320.png','docs/screenshots/catalog-model-full-320.png','docs/offline_session_outbox.md','docs/screenshots/offline-draft-390.png','docs/screenshots/offline-queue-320.png','docs/screenshots/offline-delivered-320.png',
 'docs/screenshots/sync-device-a.png','docs/screenshots/sync-device-b.png','docs/screenshots/sync-download-confirm.png','docs/screenshots/sync-conflict-320.png','.dockerignore')


def prepareServer(output):
    output=Path(output).expanduser().resolve()
    if output.exists():raise ValueError('Выберите новую папку для серверного пакета')
    contents={name:(ROOT/name).read_bytes() for name in FILES}
    for name,data in contents.items():
        if name.endswith('.py'):ast.parse(data)
    try:commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
    except (OSError,subprocess.CalledProcessError):commit=None
    output.mkdir(parents=True)
    for name,data in contents.items():
        target=output/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    (output/'SERVER_MANIFEST.json').write_text(json.dumps({'sourceCommit':commit,'files':{name:hashlib.sha256(data).hexdigest() for name,data in contents.items()}},ensure_ascii=False,indent=2))
    return output


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True)
    args=parser.parse_args()
    try:print(prepareServer(args.output))
    except (ValueError,OSError) as error:parser.exit(1,str(error)+'\n')
