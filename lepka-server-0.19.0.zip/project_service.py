import re
from datetime import datetime

from database import (
    createProject,
    createProjectWithSteps,
    updateProjectById,
    updateProjectStepDescription,
    getProjectById,
    createProjectStep,
    deleteProjectById,
    deleteProjectStepById,
    getProjectStepsByProjectId,
    getProjectsByUserId,
    updateProjectProgress,
    updateProjectStepStatus,
    getProjectStepPhoto, setProjectStepPhoto,
    reorderProjectSteps,
)
from photo_service import preparePhoto


# userId в операциях передаётся из текущей сессии пользователя,
# а не из поля формы. Проверка владельца выполняется также в database.py.
PROJECT_CATEGORIES = [
    "Животные",
    "Персонажи",
    "Еда",
    "Транспорт",
    "Аниме",
    "Кавай",
    "Фэнтези",
    "Реализм",
    "Другое",
]


def validateProjectName(projectName):
    if not projectName:
        return "Введите название проекта"

    if len(projectName) < 3:
        return "Название проекта должно быть не короче 3 символов"

    if len(projectName) > 80:
        return "Название проекта должно быть не длиннее 80 символов"

    return None


def validateProjectDescription(descriptionText):
    if descriptionText is None:
        return None

    if len(descriptionText) > 1500:
        return "Описание должно быть не длиннее 1500 символов"

    return None


def validateStepDescription(stepDescription):
    if not isinstance(stepDescription, str) or not stepDescription.strip():
        return "Введите описание этапа"

    if len(stepDescription.strip()) < 3:
        return "Описание этапа должно быть не короче 3 символов"

    if len(stepDescription.strip()) > 1000:
        return "Описание этапа должно быть не длиннее 1000 символов"

    return None


def validateProjectDeadline(deadlineDate):
    # Пустая дата означает «Без дедлайна». Прошедшие даты допустимы.
    if not deadlineDate:
        return None
    error = "Введите дедлайн в формате ДД.ММ.ГГГГ (например: 25.04.2026)"
    if not re.fullmatch(r"[0-9]{2}\.[0-9]{2}\.[0-9]{4}", deadlineDate):
        return error
    try:
        datetime.strptime(deadlineDate, "%d.%m.%Y")
    except ValueError:
        return "Такой даты не существует. Проверьте день, месяц и год"
    return None


def normalizeProjectData(projectName, categoryName, deadlineDate, descriptionText):
    projectName = (projectName or '').strip()
    descriptionText = (descriptionText or '').strip()
    deadlineDate = (deadlineDate or '').strip()
    for error in (validateProjectName(projectName), validateProjectDescription(descriptionText),
                  validateProjectDeadline(deadlineDate)):
        if error:
            raise ValueError(error)
    if categoryName not in PROJECT_CATEGORIES:
        raise ValueError('Выберите категорию проекта из списка')
    return projectName, categoryName, deadlineDate, descriptionText


def saveProject(userId, projectName, categoryName, deadlineDate, descriptionText, stepDescriptions=None):
    try:
        projectName, categoryName, deadlineDate, descriptionText = normalizeProjectData(
            projectName, categoryName, deadlineDate, descriptionText)
    except ValueError as error:
        return False, str(error), None

    if stepDescriptions is not None:
        if not isinstance(stepDescriptions, list) or len(stepDescriptions) > 100:
            return False, "Допускается не больше 100 этапов", None
        normalizedSteps = []
        for description in stepDescriptions:
            error = validateStepDescription(description)
            if error:
                return False, error, None
            normalizedSteps.append(description.strip())
        projectId = createProjectWithSteps(userId, projectName, categoryName, deadlineDate, descriptionText, normalizedSteps)
        return True, "Проект с этапами сохранён", projectId

    projectId = createProject(
        userId,
        projectName,
        categoryName,
        deadlineDate,
        descriptionText,
    )

    return True, "Проект сохранён", projectId


def getProjectSteps(projectId, userId):
    stepRecords = getProjectStepsByProjectId(projectId, userId)

    stepItems = []

    for stepRecord in stepRecords:
        stepItems.append(
            {
                "stepId": stepRecord["stepId"],
                "projectId": stepRecord["projectId"],
                "stepDescription": stepRecord["stepDescription"],
                "title": stepRecord["stepDescription"],
                "details": stepRecord["detailsText"],
                "isCompleted": bool(stepRecord["isCompleted"]),
                "hasPhoto": bool(stepRecord['hasPhoto']),
                "createdAt": stepRecord["createdAt"],
            }
        )

    return stepItems


def saveProjectStepOrder(projectId, userId, orderedIds, expectedIds):
    for ids in (orderedIds, expectedIds):
        if not isinstance(ids, (list, tuple)) or any(type(value) is not int for value in ids):
            return False, 'Некорректный список этапов'
    try:
        success = reorderProjectSteps(projectId, userId, orderedIds, expectedIds)
    except ValueError as error:
        return False, str(error)
    return success, 'Порядок этапов сохранён' if success else 'Проект не найден или недоступен'


def calculateProjectProgress(projectId, userId):
    if getProjectById(projectId, userId) is None:
        return None
    stepItems = getProjectSteps(projectId, userId)

    if len(stepItems) == 0:
        return 100 if getProjectById(projectId,userId)["isFinished"] else 0

    completedCount = 0

    for stepItem in stepItems:
        if stepItem["isCompleted"]:
            completedCount += 1

    progress = round(completedCount / len(stepItems) * 100, 1)
    return progress if completedCount == len(stepItems) else min(99.9, progress)


def refreshProjectProgress(projectId, userId):
    progressPercent = calculateProjectProgress(projectId, userId)
    if progressPercent is None:
        return None
    if not updateProjectProgress(projectId, progressPercent, userId):
        return None

    return progressPercent


def getUserProjects(userId):
    projectRecords = getProjectsByUserId(userId)

    projectItems = []

    for projectRecord in projectRecords:
        projectId = projectRecord["projectId"]
        progressPercent = refreshProjectProgress(projectId, userId)
        if progressPercent is None:
            continue  # Проект мог быть удалён после получения списка.
        stepItems = getProjectSteps(projectId, userId)

        projectItems.append(
            {
                "projectId": projectId,
                "projectName": projectRecord["projectName"],
                "categoryName": projectRecord["categoryName"],
                "deadlineDate": projectRecord["deadlineDate"],
                "descriptionText": projectRecord["descriptionText"],
                "progressPercent": progressPercent,
                "isFinished": bool(projectRecord["isFinished"]),
                "hasFinalPhoto": bool(projectRecord["hasFinalPhoto"]),
                "completedAt": projectRecord["completedAt"],
                "stepItems": stepItems,
                "createdAt": projectRecord["createdAt"],
            }
        )

    return projectItems


def removeProject(projectId, userId):
    return deleteProjectById(projectId, userId)


def saveProjectStep(projectId, stepDescription, userId):
    stepDescription = (stepDescription or "").strip()

    stepDescriptionError = validateStepDescription(stepDescription)
    if stepDescriptionError:
        return False, stepDescriptionError, None

    stepId = createProjectStep(projectId, stepDescription, userId)
    if stepId is None:
        return False, "Проект не найден или недоступен", None
    refreshProjectProgress(projectId, userId)

    return True, "Этап добавлен", stepId


def changeProjectStepStatus(projectId, stepId, isCompleted, userId):
    if not updateProjectStepStatus(projectId, stepId, isCompleted, userId):
        return None
    progressPercent = refreshProjectProgress(projectId, userId)

    return progressPercent


def saveProjectStepPhoto(projectId, stepId, userId, photo):
    if not isinstance(photo, dict):
        return False, 'Выберите фотографию'
    try:
        data = preparePhoto(photo.get('name'), photo.get('data'))['data']
    except ValueError as error:
        return False, str(error)
    if not setProjectStepPhoto(projectId, stepId, userId, data):
        return False, 'Этап не найден или недоступен'
    return True, 'Фото этапа сохранено'


def removeProjectStepPhoto(projectId, stepId, userId):
    if not setProjectStepPhoto(projectId, stepId, userId, None):
        return False, 'Этап не найден или недоступен'
    return True, 'Фото этапа удалено'


def removeProjectStep(projectId, stepId, userId):
    if not deleteProjectStepById(projectId, stepId, userId):
        return None
    progressPercent = refreshProjectProgress(projectId, userId)

    return progressPercent



def editProject(projectId, userId, projectName, categoryName, deadlineDate, descriptionText):
    try:
        values = normalizeProjectData(projectName, categoryName, deadlineDate, descriptionText)
    except ValueError as error:
        return False, str(error)
    if not updateProjectById(projectId, userId, *values):
        return False, 'Проект не найден или недоступен'
    return True, 'Проект изменён'


def editProjectStep(projectId, stepId, userId, description):
    error = validateStepDescription(description)
    if error:
        return False, error
    if not updateProjectStepDescription(projectId, stepId, userId, description.strip()):
        return False, 'Этап не найден или недоступен'
    return True, 'Этап изменён'


def saveStep(projectId,userId,title,details='',stepId=None):
    from database import updateStepDetails
    error=validateStepDescription(title)
    if error:return False,error.replace('Описание','Название').replace('описание','название'),None
    if not isinstance(details,str) or len(details)>900:return False,'Описание этапа: до 900 символов',None
    if stepId is None:
        # Both fields are committed together: no half-created stages on failure.
        from database import openDatabase
        with openDatabase() as connection:
            connection.execute('BEGIN IMMEDIATE')
            count=connection.execute('SELECT COUNT(*) FROM projectSteps s JOIN projects p ON p.projectId=s.projectId WHERE p.projectId=? AND p.userId=?',(projectId,userId)).fetchone()[0]
            if count>=100:return False,'Допускается не больше 100 этапов',None
            cursor=connection.execute("""INSERT INTO projectSteps(projectId,stepDescription,detailsText,sortOrder)
                SELECT projectId,?,?,COALESCE((SELECT MAX(sortOrder) FROM projectSteps WHERE projectId=?),-1)+1 FROM projects WHERE projectId=? AND userId=?""",
                (title.strip(),details.strip(),projectId,projectId,userId))
            if not cursor.rowcount:return False,'Проект недоступен',None
            stepId=cursor.lastrowid
            connection.execute('UPDATE projects SET isFinished=0,completedAt=NULL WHERE projectId=? AND userId=?',(projectId,userId))
        refreshProjectProgress(projectId,userId)
    elif not updateStepDetails(projectId,stepId,userId,title.strip(),details.strip()):return False,'Этап недоступен',None
    return True,'Этап сохранён',stepId


def saveFinalPhoto(projectId,userId,photo):
    from database import setFinalPhoto
    try:data=preparePhoto(photo.get('name'),photo.get('data'))['data']
    except (ValueError,AttributeError) as error:return False,str(error)
    return (True,'Финальное фото сохранено') if setFinalPhoto(projectId,userId,data) else (False,'Проект недоступен')


def removeFinalPhoto(projectId,userId):
    from database import setFinalPhoto
    return (True,'Финальное фото удалено') if setFinalPhoto(projectId,userId,None) else (False,'Сначала верните проект в работу')


def finishProject(projectId,userId,finished=True):
    from database import finishProjectRecord
    if type(finished) is not bool:return False,'Некорректный статус'
    try:ok=finishProjectRecord(projectId,userId,finished)
    except ValueError as error:return False,str(error)
    return ok,('Проект завершён' if finished else 'Проект возвращён в работу') if ok else 'Проект недоступен'
