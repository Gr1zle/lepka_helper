"""Каталог встроенных OBJ и личное избранное моделей."""
from copy import deepcopy
from functools import lru_cache
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from database import openDatabase
from learning_assets import MODEL_ITEMS
from mesh_renderer import parseObj
from model_import import importedModel,listImportedModels

ASSET_ROOT=Path(__file__).resolve().parent/'assets'
MODEL_CATEGORIES=('Все',*dict.fromkeys(item['category'] for item in MODEL_ITEMS),'Мои модели')


def personalItem(record):
    return {'modelId':record['modelId'],'title':record['title'],'category':'Мои модели',
            'imported':True,'previewImage':record['previewImage'],'tags':()}


def getModel(modelId,userId=None):
    if isinstance(modelId,str) and modelId.startswith('catalog-') and userId is not None:
        cached=catalogModel(modelId,userId)
        return cached[0] if cached else None
    item=next((deepcopy(item) for item in MODEL_ITEMS if item['modelId']==modelId),None)
    if item:return item
    record=importedModel(modelId,userId)
    return personalItem(record) if record else None


def requireModel(modelId,userId=None):
    model=getModel(modelId,userId)
    if model is None:raise ValueError('Модель не найдена')
    return model


@lru_cache(maxsize=6)
def loadBuiltinModel(modelId):
    requireModel(modelId)
    return parseObj((ASSET_ROOT/'models'/f'{modelId}.obj').read_text(encoding='utf-8'),
                    (ASSET_ROOT/'models'/f'{modelId}.mtl').read_text(encoding='utf-8'))


def loadModel(modelId,userId=None):
    if isinstance(modelId,str) and modelId.startswith('catalog-') and userId is not None:
        cached=catalogModel(modelId,userId)
        if not cached:raise ValueError('Сохранённая модель каталога недоступна')
        from model_import import decodeModel
        import base64
        return decodeModel(cached[1]['name'],base64.b64decode(cached[1]['contentBase64'],validate=True))['mesh']
    if any(item['modelId']==modelId for item in MODEL_ITEMS):return loadBuiltinModel(modelId)
    record=importedModel(modelId,userId)
    if not record:raise ValueError('Модель не найдена')
    return parseObj(record['objText'],record['materialText'])


def catalogModel(modelId,userId):
    import json
    from api_client import getApiUrl
    from lesson_library import requireOwner
    with openDatabase() as c:
        requireOwner(c,userId)
        row=c.execute('SELECT documentJson,assetsJson FROM learningCache WHERE userId=? AND apiUrl=? AND contentId=?',(userId,getApiUrl(),modelId[len('catalog-'):])).fetchone()
    if not row:return None
    info=json.loads(row[0]);document=info['document'];aid=document['modelAsset']
    if not aid:return None
    return (dict(modelId=modelId,title=document['title'],category=document['category'],tags=document['tags'],catalog=True),json.loads(row[1])[aid])


def searchModels(query='',category='Все',level='Все',maxTime=None,userId=None):
    from lesson_service import getLessonById,IDEA_LEVELS
    if not isinstance(query,str) or len(query)>120:
        raise ValueError('Поисковый запрос должен быть не длиннее 120 символов')
    if category not in MODEL_CATEGORIES or level not in ('Все',*IDEA_LEVELS):
        raise ValueError('Выберите категорию и сложность')
    query=' '.join(query.split()).casefold().replace('ё','е')
    if query and len(query)<2:return []
    if maxTime is not None and (isinstance(maxTime,bool) or not str(maxTime).isdecimal()):
        raise ValueError('Некорректное время')
    result=[]
    for item in MODEL_ITEMS:
        lesson=getLessonById(item['lessonId'])
        haystack=' '.join(('3d модель фигурка',item['title'],item['category'],*item['tags'],lesson['title'],lesson['description'],*lesson['materials'])).casefold().replace('ё','е')
        if (category!='Все' and item['category']!=category or level!='Все' and lesson['level']!=level
                or maxTime is not None and lesson['timeMinutes']>int(maxTime)
                or not all(word in haystack for word in query.split())):continue
        result.append(deepcopy(item))
    if userId is not None and category in ('Все','Мои модели') and level=='Все' and maxTime is None:
        for record in listImportedModels(userId):
            if all(word in ('3d модель фигурка мои модели '+record['title']).casefold().replace('ё','е') for word in query.split()):
                result.append(personalItem(record))
    return result


def favoriteModelIds(userId):
    with openDatabase() as connection:
        records=connection.execute('''SELECT f.modelId FROM modelFavorites f JOIN users u ON u.userId=f.userId
            WHERE f.userId=? AND u.isBlocked=0''',(userId,)).fetchall()
    return {row['modelId'] for row in records if getModel(row['modelId'],userId)}


def saveModelFavorite(userId,modelId,selected):
    requireModel(modelId,userId)
    if type(selected) is not bool:raise ValueError('Некорректная отметка избранного')
    with openDatabase() as connection:
        connection.execute('BEGIN IMMEDIATE')
        if connection.execute("SELECT userId FROM users WHERE userId=? AND isBlocked=0 AND roleName!='deleted'",(userId,)).fetchone() is None:
            raise ValueError('Аккаунт недоступен')
        if selected:
            connection.execute('INSERT OR IGNORE INTO modelFavorites(userId,modelId) VALUES (?,?)',(userId,modelId))
        else:
            connection.execute('DELETE FROM modelFavorites WHERE userId=? AND modelId=?',(userId,modelId))
    return selected


def modelBundle(modelId,userId=None):
    item=requireModel(modelId,userId)
    output=BytesIO()
    with ZipFile(output,'w',ZIP_DEFLATED) as archive:
        if item.get('catalog'):
            import base64
            from model_import import decodeModel
            cached=catalogModel(modelId,userId)
            decoded=decodeModel(cached[1]['name'],base64.b64decode(cached[1]['contentBase64'],validate=True))
            archive.writestr('model.obj',decoded['objText']);archive.writestr('model.mtl',decoded['materialText'])
            archive.writestr('README.txt','Saved learning catalogue model from Lepka Helper.\n')
        elif item.get('imported'):
            record=importedModel(modelId,userId)
            if not record:raise ValueError('Модель не найдена')
            archive.writestr('model.obj',record['objText'])
            archive.writestr('model.mtl',record['materialText'])
            archive.writestr('README.txt','Personal OBJ model exported from Lepka Helper.\n')
        else:
            for extension in ('obj','mtl'):
                name=f'{modelId}.{extension}'
                archive.writestr(name,(ASSET_ROOT/'models'/name).read_bytes())
            archive.writestr('README.txt','Author-created geometric learning model from Lepka Helper.\nKeep OBJ and MTL in the same folder.\n')
    return output.getvalue()
